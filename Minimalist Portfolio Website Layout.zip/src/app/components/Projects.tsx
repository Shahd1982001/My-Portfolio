import { motion } from "motion/react";
import { ArrowRight, Sparkles } from "lucide-react";

const projects = [
  {
    title: "Masgi App",
    description: "A beautifully crafted traditional recipe digital library.",
    gradient: "from-purple-400 to-pink-400"
  },
  {
    title: "Neo Wallet",
    description: "A sleek and modern financial/crypto wallet interface.",
    gradient: "from-lavender-400 to-purple-500"
  },
  {
    title: "AURA",
    description: "An elegant UI/UX design case study.",
    gradient: "from-purple-500 to-indigo-500"
  },
  {
    title: "Roboleg App",
    description: "An innovative mobile application interface integrated with assistive voice-controlled tech.",
    gradient: "from-pink-400 to-purple-400"
  }
];

export function Projects() {
  return (
    <section id="projects" className="py-24 px-8 bg-gradient-to-b from-white via-purple-50/30 to-lavender-50/50 relative overflow-hidden">
      {/* Background decorative shapes */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-purple-200/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-40 left-20 w-96 h-96 bg-lavender-200/20 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center space-y-4 mb-16"
        >
          <div className="inline-flex items-center gap-2 px-5 py-2 bg-purple-50 rounded-full border border-purple-100">
            <Sparkles className="w-4 h-4 text-purple-500" />
            <span className="text-sm tracking-wide text-purple-600 uppercase">My Portfolio</span>
          </div>

          <h2 className="text-5xl font-light">
            Featured <span className="bg-gradient-to-r from-purple-600 to-lavender-500 bg-clip-text text-transparent">Projects</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -8 }}
              className="group relative p-8 bg-white/80 backdrop-blur-sm rounded-3xl border border-purple-100/50 shadow-lg shadow-purple-100/50 hover:shadow-2xl hover:shadow-purple-200/50 transition-all duration-300 cursor-pointer overflow-hidden"
            >
              {/* Gradient overlay */}
              <div className={`absolute top-0 right-0 w-40 h-40 bg-gradient-to-br ${project.gradient} opacity-10 group-hover:opacity-20 rounded-full blur-2xl transition-opacity duration-300 -mr-10 -mt-10`}></div>

              <div className="relative z-10">
                <div className="flex items-start justify-between mb-4">
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${project.gradient} flex items-center justify-center shadow-lg`}>
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>

                  <motion.div
                    className="opacity-0 group-hover:opacity-100 transition-opacity"
                    whileHover={{ x: 5 }}
                  >
                    <ArrowRight className="w-5 h-5 text-purple-500" />
                  </motion.div>
                </div>

                <h3 className="text-2xl mb-3 bg-gradient-to-r from-gray-800 to-gray-600 bg-clip-text text-transparent">
                  {project.title}
                </h3>

                <p className="text-gray-600 leading-relaxed">
                  {project.description}
                </p>

                {/* Decorative line */}
                <div className="mt-6 w-16 h-0.5 bg-gradient-to-r from-purple-400 to-transparent rounded-full group-hover:w-24 transition-all duration-300"></div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Bottom decorative wave */}
      <svg className="absolute bottom-0 left-0 w-full h-24 opacity-10" viewBox="0 0 1200 100" preserveAspectRatio="none">
        <path d="M0,50 Q300,80 600,50 T1200,50 L1200,100 L0,100 Z" fill="#9333ea" />
      </svg>
    </section>
  );
}
